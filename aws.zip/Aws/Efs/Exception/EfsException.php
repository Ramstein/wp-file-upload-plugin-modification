<?php
namespace Aws\Efs\Exception;

use Aws\Exception\AwsException;

/**
 * Amazon EFS exception.
 */
class EfsException extends AwsException {}
