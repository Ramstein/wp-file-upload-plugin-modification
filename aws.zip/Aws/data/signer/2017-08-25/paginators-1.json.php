<?php
// This file was auto-generated from sdk-root/src/data/signer/2017-08-25/paginators-1.json
return [ 'pagination' => [ 'ListSigningJobs' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'ListSigningPlatforms' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'ListSigningProfiles' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], ],];
