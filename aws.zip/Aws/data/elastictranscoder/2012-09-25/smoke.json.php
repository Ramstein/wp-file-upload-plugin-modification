<?php
// This file was auto-generated from sdk-root/src/data/elastictranscoder/2012-09-25/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListPresets', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'ReadJob', 'input' => [ 'Id' => 'fake_job', ], 'errorExpectedFromService' => true, ], ],];
