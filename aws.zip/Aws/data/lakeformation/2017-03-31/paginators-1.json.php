<?php
// This file was auto-generated from sdk-root/src/data/lakeformation/2017-03-31/paginators-1.json
return [ 'pagination' => [ 'GetEffectivePermissionsForPath' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListPermissions' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListResources' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
